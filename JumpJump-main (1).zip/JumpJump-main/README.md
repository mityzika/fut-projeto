# JOGO DE CORRIDA COM OBSTÁCULOS
No jogo você controla uma bola, onde ela tem que correr e pular os obstáculos que vão surgindo, com o intuito de fazer  melhor pontuação possível!<br>
Este game foi desenvolvido com o auxilio de uma playlist no youtube: https://www.youtube.com/watch?v=z3r8up9cz3w&list=PL1EkVGo1AQ0Hsqhvjm4khfp6innDjpj9J
